from copy import deepcopy

used_faux_dicts = []

# Function to apply swaps to a list
def apply_swaps(lst, swaps):
    for a, b in swaps:
        try:
            index = lst.index(a)
            if index < len(lst) - 1 and lst[index + 1] == b:
                lst[index], lst[index + 1] = lst[index + 1], lst[index]
        except ValueError:
            continue

# Read function title lol
def initialize_lists_and_pairs(k):
    k_minus = k - 1
    list_1 = list(range(1, k_minus + 1))
    list_2 = list(range(1, k_minus + 1))

    # Pre-populate swapped_pairs_1 and swapped_pairs_2 with initial pairs
    swapped_pairs_1 = [(i, i + 1) for i in range(1, k_minus - 1, 2)]
    swapped_pairs_2 = [(i, i + 1) for i in range(2, k_minus, 2)]
    if k_minus % 2 == 0:
        swapped_pairs_1 = [(i, i + 1) for i in range(1, k_minus, 2)]

    # Apply the prefilled swaps to list_1 and list_2
    apply_swaps(list_1, swapped_pairs_1)
    apply_swaps(list_2, swapped_pairs_2)

    return list_1, list_2

# Precompute the initial possible_pairs
def compute_possible_pairs(lst, k):
    possibles = [(min(lst[i], lst[i + 1]), max(lst[i + 1], lst[i])) for i in range(len(lst) - 1) 
                 if lst[i] not in (lst[i+1]-1, lst[i+1]+1) and lst[i] + lst[i+1] <= k]
    return possibles

# Function to generate the mirrored version of the selected_list
def generate_mirrored_list(selected_list, k):
    return [k - x for x in reversed(selected_list)]

# True if NOT sequential ascending
def sequential_test(pair):
    return pair[0] + 1 != pair[1]

# Test if the swap made a triangle
def triangle_test(fauxdict, pair):
    return fauxdict[pair[0] - 1][-1] == fauxdict[pair[1] - 1][-1]

# Test if the necessary secondary swaps are both valid
def secondary_pair_test_a(fauxdict, all_swapped, pair1, pair2):
    a = sequential_test(pair1)
    b = sequential_test(pair2)
    c = triangle_test(fauxdict, pair1)
    d = triangle_test(fauxdict, pair2)
    e = not(pair1 in all_swapped or pair2 in all_swapped)
    return a and b and c and d and e

def secondary_pair_test_b(fauxdict, all_swapped, pair):
    a = sequential_test(pair)
    c = triangle_test(fauxdict, pair)
    e = not(pair in all_swapped)
    return a and c and e

def prev_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, prev_pair):
    # Perform the prev swap
    selected_list[swap_index - 1], selected_list[swap_index] = selected_list[swap_index], selected_list[swap_index - 1]

    # Update fauxdict for the prev swap
    selected_fauxdict[prev_pair[0] - 1].append(prev_pair[1])
    selected_fauxdict[prev_pair[1] - 1].append(prev_pair[0])

    # Add to swapped list
    all_swapped.add(prev_pair)
    all_swapped_o.append(prev_pair)
    return

def next_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, next_pair):
    # Perform the next swap
    selected_list[swap_index + 1], selected_list[swap_index + 2] = selected_list[swap_index + 2], selected_list[swap_index + 1]

    # Update fauxdict for the next swap
    selected_fauxdict[next_pair[0] - 1].append(next_pair[1])
    selected_fauxdict[next_pair[1] - 1].append(next_pair[0])

    # Add to swapped list
    all_swapped.add(next_pair)
    all_swapped_o.append(next_pair)
    return

# Function to handle common logic for both first_pass and next_pass
def pass_logic(i, pair, original_list, fauxdict, all_swapped_pairs, all_swapped_ordered, recorded_passes, pass_number, k, code, exceptions, exception_limit):
    selected_list = original_list.copy()
    selected_fauxdict = deepcopy(fauxdict)
    all_swapped = all_swapped_pairs.copy()
    all_swapped_o = all_swapped_ordered.copy()

    swap_index = i
    subcode = 0

    # Perform the primary swap
    selected_list[swap_index], selected_list[swap_index + 1] = selected_list[swap_index + 1], selected_list[swap_index]
    # Update selected_fauxdict for the primary swap
    selected_fauxdict[pair[0] - 1].append(pair[1])
    selected_fauxdict[pair[1] - 1].append(pair[0])

    # Add the main swap to the set of swapped pairs
    all_swapped.add(pair)
    all_swapped_o.append(pair)

    # Check if the primary swap results in a triangle
    if pair[0] + pair[1] == k:
        if not triangle_test(selected_fauxdict, pair):
            # For the case when double excepting is valid
            if exceptions + 2 <= exception_limit:
                record_pass(selected_list, all_swapped, all_swapped_o, selected_fauxdict, recorded_passes, pass_number, k, code + str(subcode), exceptions + 2)
            subcode += 1
            
            prev_pair = (min(selected_list[swap_index - 1], selected_list[swap_index]),
                max(selected_list[swap_index - 1], selected_list[swap_index]))
            next_pair = (min(selected_list[swap_index + 1], selected_list[swap_index + 2]),
                max(selected_list[swap_index + 1], selected_list[swap_index + 2]))
            
            if secondary_pair_test_a(selected_fauxdict, all_swapped_pairs, prev_pair, next_pair):
                if exceptions == exception_limit:
                    prev_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, prev_pair)
                    next_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, next_pair)
                    record_pass(selected_list, all_swapped, all_swapped_o, selected_fauxdict, recorded_passes, pass_number, k, code + str(subcode), exceptions)
                    return
                else:
                    selected_list_b = selected_list.copy()
                    selected_fauxdict_b = deepcopy(selected_fauxdict)
                    all_swapped_b = all_swapped.copy()
                    all_swapped_o_b = all_swapped_o.copy()

                    prev_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, prev_pair)
                    record_pass(selected_list, all_swapped, all_swapped_o, selected_fauxdict, recorded_passes, pass_number, k, code + str(subcode), exceptions + 1)
                    subcode += 1

                    next_swap(selected_list_b, selected_fauxdict_b, all_swapped_b, all_swapped_o_b, swap_index, next_pair)
                    record_pass(selected_list_b, all_swapped_b, all_swapped_o_b, selected_fauxdict_b, recorded_passes, pass_number, k, code + str(subcode), exceptions + 1)
                    subcode += 1

                    next_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, next_pair)
                    record_pass(selected_list, all_swapped, all_swapped_o, selected_fauxdict, recorded_passes, pass_number, k, code + str(subcode), exceptions)
                    return
            elif secondary_pair_test_b(selected_fauxdict, all_swapped_pairs, prev_pair):
                exceptions += 1
                if exceptions > exception_limit:
                    return
                prev_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, prev_pair)
                record_pass(selected_list, all_swapped, all_swapped_o, selected_fauxdict, recorded_passes, pass_number, k, code + str(subcode), exceptions)
                return 
            elif secondary_pair_test_b(selected_fauxdict, all_swapped_pairs, next_pair):
                exceptions += 1
                if exceptions > exception_limit:
                    return
                next_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, next_pair)
                record_pass(selected_list, all_swapped, all_swapped_o, selected_fauxdict, recorded_passes, pass_number, k, code + str(subcode), exceptions)
                return
    else:
        mpair = (k - pair[1], k - pair[0])
        m_swap_index = k - swap_index - 3
        # Perform the m primary swap
        selected_list[m_swap_index], selected_list[m_swap_index + 1] = selected_list[m_swap_index + 1], selected_list[m_swap_index]

        #print(mpair)
        #print(selected_list)

        # Update selected_fauxdict for the m primary swap
        selected_fauxdict[mpair[0] - 1].append(mpair[1])
        selected_fauxdict[mpair[1] - 1].append(mpair[0])

        # Add the main swap to the set of swapped pairs
        all_swapped.add(mpair)
        all_swapped_o.append(mpair)
        if not triangle_test(selected_fauxdict, pair):
            # For the case when double excepting is valid
            if exceptions + 4 <= exception_limit:
                record_pass(selected_list, all_swapped, all_swapped_o, selected_fauxdict, recorded_passes, pass_number, k, code + str(subcode), exceptions + 2)
            subcode += 1
            first = (min(selected_list[0], selected_list[1]), max(selected_list[0], selected_list[1]))
            last = (min(selected_list[-2], selected_list[-1]), max(selected_list[-2], selected_list[-1]))
            if first == pair:
                exceptions += 2
                if exceptions > exception_limit:
                    return
                else:
                    m_prev_pair = (min(selected_list[m_swap_index - 1], selected_list[m_swap_index]),
                        max(selected_list[m_swap_index - 1], selected_list[m_swap_index]))
                    next_pair = (min(selected_list[swap_index + 1], selected_list[swap_index + 2]),
                        max(selected_list[swap_index + 1], selected_list[swap_index + 2]))
                    
                    if secondary_pair_test_b(selected_fauxdict, all_swapped_pairs, next_pair):
                        prev_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, m_swap_index, m_prev_pair)
                        next_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, next_pair)
                        record_pass(selected_list, all_swapped, all_swapped_o, selected_fauxdict, recorded_passes, pass_number, k, code + str(subcode), exceptions)
                        return
                    else: return
            elif last == pair:
                exceptions += 2
                if exceptions > exception_limit:
                    return
                else:
                    prev_pair = (min(selected_list[swap_index - 1], selected_list[swap_index]),
                        max(selected_list[swap_index - 1], selected_list[swap_index]))
                    m_next_pair = (min(selected_list[m_swap_index + 1], selected_list[m_swap_index + 2]),
                        max(selected_list[m_swap_index + 1], selected_list[m_swap_index + 2]))
                    
                    if secondary_pair_test_b(selected_fauxdict, all_swapped_pairs, next_pair):
                        prev_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, m_swap_index, prev_pair)
                        next_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, m_next_pair)
                        record_pass(selected_list, all_swapped, all_swapped_o, selected_fauxdict, recorded_passes, pass_number, k, code + str(subcode), exceptions)
                        return
                    else: return
            else:
                prev_pair = (min(selected_list[swap_index - 1], selected_list[swap_index]),
                    max(selected_list[swap_index - 1], selected_list[swap_index]))
                m_prev_pair = (min(selected_list[m_swap_index - 1], selected_list[m_swap_index]),
                    max(selected_list[m_swap_index - 1], selected_list[m_swap_index]))
                next_pair = (min(selected_list[swap_index + 1], selected_list[swap_index + 2]),
                    max(selected_list[swap_index + 1], selected_list[swap_index + 2]))
                m_next_pair = (min(selected_list[m_swap_index + 1], selected_list[m_swap_index + 2]),
                    max(selected_list[m_swap_index + 1], selected_list[m_swap_index + 2]))
                
                if secondary_pair_test_a(selected_fauxdict, all_swapped_pairs, prev_pair, next_pair):
                    if exceptions == exception_limit:
                        prev_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, prev_pair)
                        next_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, next_pair)
                        if m_prev_pair != next_pair:
                            prev_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, m_swap_index, m_prev_pair)
                        if m_next_pair != prev_pair:
                            next_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, m_swap_index, m_next_pair)
                        record_pass(selected_list, all_swapped, all_swapped_o, selected_fauxdict, recorded_passes, pass_number, k, code + str(subcode), exceptions)
                        return
                    elif exceptions + 1 < exception_limit:
                        selected_list_b = selected_list.copy()
                        selected_fauxdict_b = deepcopy(selected_fauxdict)
                        all_swapped_b = all_swapped.copy()
                        all_swapped_o_b = all_swapped_o.copy()

                        prev_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, prev_pair)
                        next_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, m_swap_index, m_next_pair)
                        record_pass(selected_list, all_swapped, all_swapped_o, selected_fauxdict, recorded_passes, pass_number, k, code + str(subcode), exceptions + 2)
                        subcode += 1

                        next_swap(selected_list_b, selected_fauxdict_b, all_swapped_b, all_swapped_o_b, swap_index, next_pair)
                        prev_swap(selected_list_b, selected_fauxdict_b, all_swapped_b, all_swapped_o_b, m_swap_index, m_prev_pair)
                        record_pass(selected_list_b, all_swapped_b, all_swapped_o_b, selected_fauxdict_b, recorded_passes, pass_number, k, code + str(subcode), exceptions + 2)
                        subcode += 1

                        next_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, next_pair)
                        prev_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, m_swap_index, m_prev_pair)
                        record_pass(selected_list, all_swapped, all_swapped_o, selected_fauxdict, recorded_passes, pass_number, k, code + str(subcode), exceptions)
                        return
                elif secondary_pair_test_b(selected_fauxdict, all_swapped_pairs, prev_pair):
                    exceptions += 2
                    if exceptions > exception_limit:
                        return
                    prev_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, prev_pair)
                    next_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, m_swap_index, m_next_pair)
                    record_pass(selected_list, all_swapped, all_swapped_o, selected_fauxdict, recorded_passes, pass_number, k, code + str(subcode), exceptions)
                    return 
                elif secondary_pair_test_b(selected_fauxdict, all_swapped_pairs, next_pair):
                    exceptions += 2
                    if exceptions > exception_limit:
                        return
                    next_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, swap_index, next_pair)
                    prev_swap(selected_list, selected_fauxdict, all_swapped, all_swapped_o, m_swap_index, m_prev_pair)
                    record_pass(selected_list, all_swapped, all_swapped_o, selected_fauxdict, recorded_passes, pass_number, k, code + str(subcode), exceptions)
                    return
    return

# Function to record each pass, while preventing mirrored sets
def record_pass(selected_list, all_swapped, all_swapped_ordered, selected_fauxdict, recorded_passes, pass_number, k, code, exceptions):

    global used_faux_dicts
    fauxdict_tupled = tuple((tuple(value)) for value in selected_fauxdict)

    before_len = len(used_faux_dicts[exceptions])
    used_faux_dicts[exceptions].add(fauxdict_tupled)
    after_len = len(used_faux_dicts[exceptions])

    if before_len != after_len:

        # Record the pass with its pass number
        recorded_passes.append({
            "pass_number": pass_number,
            "code": code,
            "selected_list": selected_list,
            "all_swapped": all_swapped,
            "all_swapped_ordered": all_swapped_ordered,
            "selected_fauxdict": selected_fauxdict,
            "exceptions": exceptions
        })

    

# Probably could have just combined with next_pass lol
def first_pass(k, list_2, possible_pairs, fauxdict_right, exception_limit):
    original_list = list_2.copy()  # Keep a copy of the original list
    all_swapped_pairs = set()      # Keep track of all swapped pairs
    all_swapped_ordered = []       # Keep track of all swapped pairs in order
    recorded_passes = []           # List to store each turn's result
    code = 0
    exceptions = 0

    for pair in possible_pairs:
        # Ignore if pair fails sequential test
        if not sequential_test(pair):
            continue
        val = min(pair[0], pair[1])
        i = original_list.index(val)
        # Use pass_logic for swapping
        pass_logic(i, pair, original_list, fauxdict_right, all_swapped_pairs, all_swapped_ordered, recorded_passes, 1, k, str(code), exceptions, exception_limit)
        code += 1

    # Return recorded passes for next_pass usage
    return recorded_passes

# Function for the subsequent passes
def next_pass(k, recorded_passes, exception_limit, previous_pass_number):
    new_pass_number = previous_pass_number + 1
    new_recorded_passes = []

    # Process only the passes from the previous pass
    for pass_data in recorded_passes:
        if pass_data['pass_number'] == previous_pass_number:
            selected_list = pass_data['selected_list']
            all_swapped = pass_data['all_swapped']
            all_swapped_ordered = pass_data['all_swapped_ordered']
            selected_fauxdict = pass_data['selected_fauxdict']
            prev_code = pass_data['code']
            exceptions = pass_data['exceptions']

            possible_pairs = compute_possible_pairs(selected_list, k)

            code = 0

            for pair in possible_pairs:
                # Ignore if pair contains 1 or k - 1, or other excluded pairs
                if pair in all_swapped:
                    continue

                val = min(pair[0], pair[1])
                i = selected_list.index(val)

                # Use pass_logic for swapping
                pass_logic(i, pair, selected_list, selected_fauxdict, all_swapped, all_swapped_ordered, recorded_passes, new_pass_number, k, prev_code + "," + str(code), exceptions, exception_limit)
                code += 1

    
    
    return recorded_passes + new_recorded_passes

# No need to use keys when using integers to begin with, but it acts like a dict
def generate_fauxdicts(k):
    fauxdict_left = [[] for _ in range(k - 1)]  # Create a list of empty lists
    fauxdict_right = [[] for _ in range(k - 1)]
    fauxdicts = [fauxdict_left, fauxdict_right]
    kmod = k % 2

    # Populate fauxdict_left
    for i in range(1, k - 1, 2):
        fauxdict_left[i - 1].append(i + 1)
        fauxdict_left[i].append(i)

    # Special case 0's
    fauxdict_right[0].append(0) 
    fauxdicts[kmod][k - 2].append(0)

    for i in range(2, k - kmod, 2):
        fauxdict_right[i - 1].append(i + 1)
        fauxdict_right[i].append(i)

    return fauxdict_left, fauxdict_right

# Creates the arrangements, makes records
def kobon_arrange(k, true_for_right=True, exception_limit=0):
    l1, l2 = initialize_lists_and_pairs(k)
    fauxdict_left, fauxdict_right = generate_fauxdicts(k)
    p1, p2 = compute_possible_pairs(l1, k), compute_possible_pairs(l2, k)

    # Choose left or right
    if true_for_right:
        line_list = l2
        fauxdict = fauxdict_right
        pairs = p2
    else:
        line_list = l1
        fauxdict = fauxdict_left
        pairs = p1

    # Perform first pass and record the results
    recorded_passes = first_pass(k, line_list.copy(), pairs.copy(), deepcopy(fauxdict), exception_limit)
    past_length = len(recorded_passes)

    # Use recorded data for the next passes
    i = 1
    while True:
        recorded_passes = next_pass(k, recorded_passes, exception_limit, previous_pass_number=i)
        current_length = len(recorded_passes)
        if current_length == past_length:
            break
        past_length = current_length
        i += 1

    if not true_for_right:
        max_length = ((k - 2)*(k - 3)) // 2 
        sorted_recorded_passes = [[[] for _ in range(max_length + 1)] for _ in range(exception_limit + 1)]

        for record in recorded_passes:
            swap_len = len(record["all_swapped"])
            excs = record["exceptions"]
            sorted_recorded_passes[excs][swap_len].append(record)

            

        return sorted_recorded_passes
    """
    for pass_data in recorded_passes:
        pass_number = pass_data['pass_number']
        selected_list = pass_data['selected_list']
        all_swapped_ordered = pass_data['all_swapped_ordered']
        selected_fauxdict = pass_data['selected_fauxdict']
        code = pass_data['code']
        exceptions = pass_data['exceptions']
        
        print(f"Pass {pass_number}: Code {code}: Exc's: {exceptions}, List: {selected_list}")
        print(f"Swapped Pairs: {all_swapped_ordered}, fauxdict: {selected_fauxdict}")
        print("")
    #"""
    
    return recorded_passes

# Search for entries where the swaps don't overlap and reach the max amount
def match_records(k, exception_limit):
    global used_faux_dicts

    #max_length = 20
    max_length = ((k - 2)*(k - 3)) // 2
    half_length = max_length // 2
    if k % 2 == 1:
        half_length = max_length
    print("RIGHT")
    used_faux_dicts = [set() for _ in range(exception_limit + 1)]
    right_records = kobon_arrange(k, true_for_right=True, exception_limit=exception_limit)
    used_faux_dicts = [set() for _ in range(exception_limit + 1)]
    print("")
    print("")
    print("")
    print("LEFT")
    left_records = kobon_arrange(k, true_for_right=False, exception_limit=exception_limit)
    print("")
    print("")
    print("")
    print("CHECKING FOR MATCHES...")
    matched_records = {}

    # Iterate over each record from the right side
    for right_record in right_records:
        right_swapped_pairs = right_record["all_swapped"]
        len_right_swapped_pairs = len(right_swapped_pairs)
        matched_records[right_record["code"]] = []

        left_exceptions_required = exception_limit - right_record["exceptions"]
        left_swap_length_required = half_length - len_right_swapped_pairs
        # Compare with each left-side record
        left_records_subset = left_records[left_exceptions_required][left_swap_length_required]
        for left_record in left_records_subset:
            left_swapped_pairs = left_record["all_swapped"]

            # Only add the record if there is disjoint
            if right_swapped_pairs.isdisjoint(left_swapped_pairs):
                matched_records[right_record["code"]].append(right_record)
                matched_records[right_record["code"]].append(left_record)

    # Remove records with no matches
    matched_records = {key: value for key, value in matched_records.items() if value}

    return matched_records

matches = match_records(25, 2)
print(matches)
print(" ")

#"""
if matches:
    print("MATCHES FOUND:")
    total = 0
    for key, value in matches.items():
        print("RIGHT:")
        for k, v in value[0].items():
            print(f"{k}: {v}")
        print("-")
        print("LEFT:")
        for k, v in value[1].items():
            print(f"{k}: {v}")
        print("-")
        print("ARRANGEMENT:")
        swap_left = value[1]["all_swapped_ordered"][::-1]
        swap_right = value[0]["all_swapped_ordered"]
        print(swap_left + [0] + swap_right)
        print(" ")
        print(" ")
        total += 1
    print("total")
    print(total)
#"""

if not matches:
    print("NO MATCHES FOUND")